<?php

include 'database.php';

$a = $_POST['email'];
$b = $_POST['password'];
$c = $_POST['name'];

$sql = "INSERT INTO userDetails(Name,Email,Password) VALUES('$c','$a','$b')";
$result = $conn->query($sql);
header("Location: ../html/login.html");
?>
