<?php
session_start();
include('database.php');

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Satisfy|Bree+Serif|Candal|PT+Sans">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" ><!--color-->
    <div class="container-fluid">
    <div class="navbar-header">
            <button type = "button" class = "navbar-toggle" data-toggle = "collapse" data-target="#nvb">
                   <span class = "icon-bar"></span>
                   <span class = "icon-bar"></span>
                   <span class = "icon-bar"></span>
            </button>
      <a class="navbar-brand" href="admin.php">
              <span style = "color:white"><span style = "color:red">V</span>-<span style = "color:red">S</span>tore</span><!--<img src="img/kklogo.png" />-->
          </a>

    </div>
    </div>
  </nav>
<div id="container"  style="padding-top: 90px;">
     <div id="first">
     <?php
     $sql="SELECT * FROM userdetails";
      $result=$conn->query($sql);
      while($r=mysqli_fetch_array($result))
      { 
          $name=$r['Name'];
          $sql="SELECT * FROM solditems WHERE buyer='$name'";
          $fetch = mysqli_query($conn,$sql);
          if(mysqli_fetch_array($fetch))
        {
          echo"<h2 style='font-family: comic sans ms; padding-left: 10px;'>".$name."</h2>
       <table style='width:100%;'>
        <tr>
          <th><h2>Product</h2></th>
          <th><h2>Price</h2></th>
          <th><h2 >Quantity</h2></th>
          <th><h2>Total Price</h2></th>
          <th><h2>Seller</h2></th>
        </tr>"; 
        $sql="SELECT * FROM solditems WHERE buyer='$name'";
          $fetch = mysqli_query($conn,$sql);
          $sum=0;
          while($row = mysqli_fetch_array($fetch)) {
                  $c=$row['quantity']*$row['price'];
                  $sum+=$c;
                  echo  "<tr>
                    <td>".$row['name']."</td>
                     <td>".$row['price']."</td>
                     <td>".$row['quantity']."</td>
                     <td>".$c."</td>
                     <td>".$row['seller']."</td>
                  </tr>";  
           }
      echo"</table>
      <h3 style='padding-left: 480px; padding-top: 20px; font-family: comic sans ms;'>Total Purchases: &nbsp;&nbsp;Rs.".$sum."</h3>
      <br><br><br>";
        }
      }
      ?>
    </div>
    
<style>
body{
      
      background-color:   rgb(230, 230, 255);
      background-size: cover;
    }
table {
    border-collapse: collapse;
    width: 100%;
}

h2{
  font-family: comic sans ms;
}
th, td {
    padding: 15px;
    text-align: left;
    border: 1px solid #ebebe0;
    border-bottom: 1px solid black;
}
  .button {
    display: block;
    width: 115px;
    height: 55px;
    background: green;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}
#container {
    width: 1200px;
   
    margin: auto;
}
#first {
    width: 800px;
    float: left;
    height: 450px;
        background-color: #ebebe0;
}
#second {
    width: 400px;
    float: left;
    height: 450px;
    background-color: #c2c2a3;
}
#clear {
    clear: both;
}
.delivery{
  padding-top: 30px;
  font-size: 30px;
  font-family: times new roman;
}
</style>
</body>
</html>