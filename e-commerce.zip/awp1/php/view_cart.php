<?php

session_start();
include_once("config.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View shopping cart</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../css/style1.css" rel="stylesheet" type="text/css"></head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
    <li><a href="../php/home.php">V-Store</a></li>
      <li><a href="../php/about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Electronics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/mobile.php">Mobiles and Accessories</a></li>
          <li><a href="../php/computer.php">Computers and Accessories</a></li>
          <li><a href="../php/camera.php">Cameras and Peripherals</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clothing and Footwear<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/men.php">Men</a></li>
          <li><a href="../php/women.php">Women</a></li>
          <li><a href="../php/kids.php">Kids</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Books and More<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/book1.php">Books</a></li>
          <li><a href="../php/gaming.php">Gaming</a></li>
        </ul>
      </li>
    </ul>

    <form class="navbar-form navbar-left" action="search.php">
      <div class="input-group">
        <input type="text" class="form-control" name="query" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>

    <?php
    if(empty($_SESSION['mail']))
    {
        echo"<ul class='nav navbar-nav navbar-right'>
          <li><a href='../html/signup.html'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>
          <li><a href='../html/login.html'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>
          <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
        </ul>";
      }
      else
      {
        $a = $_SESSION['mail'];
        $b = $_SESSION['pass'];
        $sql="SELECT * FROM userdetails WHERE Email='$a' AND Password='$b'";
        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();
        $n=$row['Name'];
        echo"<ul class='nav navbar-nav navbar-right'>
          <li class='dropdown'><a class='dropdown-toggle' data-toggle='dropdown' href='#'>Hello,".$n."<span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../html/password.html'>Change Password</a></li>
            <li><a href='userorder.php'>Your orders</a></li>
           <li><a href='logout.php'>Sign out</a></li>
          </ul>
          </li>
         <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
         </ul>";
      }
    ?>
    


  </div>
</nav>


<h1 align="center">View Cart</h1>
<div class="cart-view-table-back">
<form method="post" action="cart_update.php">
<table width="100%"  cellpadding="6" cellspacing="0"><thead><tr><th>Quantity</th><th>Name</th><th>Price</th><th>Total</th><th>Remove</th></tr></thead>
  <tbody>
 	<?php
 	$order="Checkout";
	if(isset($_SESSION["cart_products"])) //check session var
    {
		$total = 0; //set initial total value
		$b = 0; //var for zebra stripe table
		foreach ($_SESSION["cart_products"] as $cart_itm)
        {
			//set variables to use in content below
			$product_name = $cart_itm["product_name"];
			$product_qty = $cart_itm["product_qty"];
			$product_price = $cart_itm["product_price"];
			$product_code = $cart_itm["id"];
		//	$product_color = $cart_itm["product_color"];
			$subtotal = ($product_price * $product_qty); //calculate Price x Qty
			
		   	$bg_color = ($b++%2==1) ? 'odd' : 'even'; //class for zebra stripe 
		    echo '<tr class="'.$bg_color.'">';
			echo '<td><input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /></td>';
			echo '<td>'.$product_name.'</td>';
			echo '<td>'.$currency.$product_price.'</td>';
			echo '<td>'.$currency.$subtotal.'</td>';
			echo '<td><input type="checkbox" name="remove_code[]" value="'.$product_code.'" /></td>';
            echo '</tr>';
			$total = ($total + $subtotal); //add subtotal to total var
        }
		
		
	}
	else
	{
		$total = 0;
	}
		
		
    ?>

    <tr><td colspan="5"><span style="float:right;text-align: right;">Amount Payable : <?php echo sprintf("%01.2f", $total);?></span></td></tr>
    <tr><td colspan="5"><a href="../php/home.php" class="button">Add More Items</a>
    <button type="submit">Update</button></td></tr>
    <!--<button type="submit" value="orders" name="orders" formaction="orders.php">orders</button></td></tr>-->
    
<!--   ////////////////// pr -->
    <?php
    if(isset($_SESSION["cart_products"]))
    {
    	if(isset($_SESSION['name']))
    	{
    		$ret = "../php/checkout.php";
    	}
    	else
    	{
    		$ret = "../html/login.html";
    	}
    	echo '<tr><td colspan="5"><a href='.$ret.' class="button">'.$order.'</a></td></tr>';
    }
    ?>
  </tbody>
</table>
<input type="hidden" name="return_url" value="<?php 
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
echo $current_url;
//session_destroy();
?>" />

</form>
</div>

</body>
</html>
