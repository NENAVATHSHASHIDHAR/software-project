<?php

session_start();
include_once("config.php");


//current URL of the Page. cart_update.php redirects back to this URL
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html>
<head>
<title>V-Store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../css/style1.css" rel="stylesheet" type="text/css">
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
    	<li><a href="../php/home.php">V-Store</a></li>
      <li><a href="about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Electronics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/mobile.php">Mobiles and Accessories</a></li>
          <li><a href="../php/computer.php">Computers and Accessories</a></li>
          <li><a href="../php/camera.php">Cameras and Peripherals</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clothing and Footwear<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/men.php">Men</a></li>
          <li><a href="../php/women.php">Women</a></li>
          <li><a href="../php/kids.php">Kids</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Books and More<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/book1.php">Books</a></li>
          <li><a href="../php/gaming.php">Gaming</a></li>
        </ul>
      </li>
    </ul>
    <form class="navbar-form navbar-left" action="search.php">
      <div class="input-group">
        <input type="text" class="form-control" name="query" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
    <?php
    	if(empty($_SESSION['mail']))
		{
    		echo"<ul class='nav navbar-nav navbar-right'>
      		<li><a href='../html/signup.html'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>
      		<li><a href='../html/login.html'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>
      		<li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
    		</ul>";
    	}
    	else
    	{
    		$a = $_SESSION['mail'];
			$b = $_SESSION['pass'];
    		$sql="SELECT * FROM userdetails WHERE Email='$a' AND Password='$b'";
    		$result = $mysqli->query($sql);
    		$row = $result->fetch_assoc();
    		$n=$row['Name'];
    		echo"<ul class='nav navbar-nav navbar-right'>
      		<li class='dropdown'><a class='dropdown-toggle' data-toggle='dropdown' href='#'>Hello,".$n."<span class='caret'></span></a>
        	<ul class='dropdown-menu'>
          	<li><a href='../html/password.html''>Change Password</a></li>
          	<li><a href='userorder.php'>Your orders</a></li>
         	 <li><a href='logout.php'>Sign out</a></li>
        	</ul>
      		</li>
     		 <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
   			 </ul>";
    	}
    ?>
    
  </div>
</nav>


<h1 align="center">Gaming</h1>

<!-- View Cart Box Start -->
<?php
if(isset($_SESSION["cart_products"]) && count($_SESSION["cart_products"])>0)
{
	echo '<div class="cart-view-table-front" id="view-cart">';
	echo '<h3>Your Shopping Cart</h3>';
	echo '<form method="post" action="cart_update.php">';
	echo '<table width="100%"  cellpadding="6" cellspacing="0">';
	echo '<tbody>';

	$total =0;
	$b = 0;
	foreach ($_SESSION["cart_products"] as $cart_itm)
	{
		$product_name = $cart_itm["product_name"];
		$product_qty = $cart_itm["product_qty"];
		$product_price = $cart_itm["product_price"];
		$product_code = $cart_itm["id"];
	//	$product_color = $cart_itm["product_color"];
		$bg_color = ($b++%2==1) ? 'odd' : 'even'; //zebra stripe
		echo '<tr class="'.$bg_color.'">';
		echo '<td>Qty <input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /></td>';
		echo '<td>'.$product_name.'</td>';
		echo '<td><input type="checkbox" name="remove_code[]" value="'.$product_code.'" /> Remove</td>';
		echo '</tr>';
		$subtotal = ($product_price * $product_qty);
		$total = ($total + $subtotal);
	}
	echo '<td colspan="4">';
	echo '<button type="submit">Update</button><a href="view_cart.php" class="button">View Cart</a>';
	echo '</td>';
	echo '</tbody>';
	echo '</table>';
	
	$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
	echo '</form>';
	echo '</div>';

}
?>
<!-- View Cart Box End -->


<!-- Products List Start -->
<?php
$mysqli->query("set @flag :='game'");

$results = $mysqli->query("SELECT  id,name,image, price FROM products WHERE type=@flag ");
if($results){ 
$products_item = '<ul class="products">';
//fetch results set as object and output HTML
while($obj = $results->fetch_object())
{
$products_item .= <<<EOT
	<li class="product">
	<form method="post" action="cart_update.php">
	<div class="product-content"><h3>{$obj->name}</h3>
	<div class="product-thumb"><img src="{$obj->image}"></div>
	<div class="product-info">
	Price {$currency}{$obj->price} 
	
	<fieldset>
<!--
	<label>
		<span>Color</span>
		<select name="product_color">
		<option value="Black">Black</option>
		<option value="Silver">Silver</option>
		</select>
	</label>
-->
	<label>
		<span>Quantity</span>
		<input type="text" size="2" maxlength="2" name="product_qty" value="1" />
	</label>
	
	</fieldset>
	<input type="hidden" name="id" value="{$obj->id}" />
	<input type="hidden" name="type" value="add" />
	<input type="hidden" name="return_url" value="{$current_url}" />
	<div align="center"><button type="submit" class="add_to_cart">Add</button></div>
	</div></div>
	</form>
	</li>
EOT;
}
$products_item .= '</ul>';
echo $products_item;
//session_destroy();
}
?>    
<!-- Products List End -->
</body>
</html>
