<?php

session_start();
include_once("config.php");


//current URL of the Page. cart_update.php redirects back to this URL
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>V-Store</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../css/style1.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php

$conn = mysqli_connect('localhost', 'root','', 'database');
    $sql = "select * from sellerdetails";
    $rs = $conn->query($sql);
    $x = $_SESSION['mail'];
    $y = $_SESSION['pass'];
    while($row = $rs->fetch_assoc()){
        if($row['email'] == $x && $row['password'] == $y){
           $g = $row['name'];
        }
      }   
?>



<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  	  <div class="navbar-header">
      <a class="navbar-brand" href="seller.php">
              <span style = "color:white"><span style = "color:red">V</span>-<span style = "color:red">S</span>tore</span>
          </a>
      </div>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hello,<?php echo $g;?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../html/sellerpass.html">Change Password</a></li>
          <li><a href="viewproducts.php">Your items</a></li>
          <li><a href="logout.php">Sign out</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>

<h1 align="center">Your Items</h1>

<!-- Products List Start -->
<?php
$results = $mysqli->query("SELECT name,image,price,quantity FROM products WHERE seller='$g'");
if($results){ 
$products_item = '<ul class="products">';
//fetch results set as object and output HTML
while($obj = $results->fetch_object())
{
$products_item .= <<<EOT
	<li class="product">
	<form method="post" action="cart_update.php">
	<div class="product-content"><h3>{$obj->name}</h3>
	<div class="product-thumb"><img src="{$obj->image}"></div>
	<div class="product-info">
	Price :{$currency}{$obj->price} 
	<div class="product-content">Quantity :{$obj->quantity}
	
	<fieldset>
<!--
	<label>
		<span>Color</span>
		<select name="product_color">
		<option value="Black">Black</option>
		<option value="Silver">Silver</option>
		</select>
	</label>
-->
	
	</div>
	</form>
	</li>
EOT;
}
$products_item .= '</ul>';
echo $products_item;
//session_destroy();
}
?>    
<!-- Products List End -->
</body>
</html>
