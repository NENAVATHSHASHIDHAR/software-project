<?php 
session_start();
include('config.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Team</title>
		 <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Satisfy|Bree+Serif|Candal|PT+Sans">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
	   
</head>
<body>
	

	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
    	<li><a href="../php/home.php">V-Store</a></li>
      <li><a href="../php/about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Electronics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/mobile.php">Mobiles and Accessories</a></li>
          <li><a href="../php/computer.php">Computers and Accessories</a></li>
          <li><a href="../php/camera.php">Cameras and Peripherals</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clothing and Footwear<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/men.php">Men</a></li>
          <li><a href="../php/women.php">Women</a></li>
          <li><a href="../php/kids.php">Kids</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Books and More<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/book1.php">Books</a></li>
          <li><a href="../php/gaming.php">Gaming</a></li>
        </ul>
      </li>
    </ul>

    <form class="navbar-form navbar-left" action="search.php">
      <div class="input-group">
        <input type="text" class="form-control" name="query" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>

    <?php
    if(empty($_SESSION['mail']))
    {
        echo"<ul class='nav navbar-nav navbar-right'>
          <li><a href='../html/signup.html'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>
          <li><a href='../html/login.html'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>
          <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
        </ul>";
      }
      else
      {
        $a = $_SESSION['mail'];
        $b = $_SESSION['pass'];
        $sql="SELECT * FROM userdetails WHERE Email='$a' AND Password='$b'";
        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();
        $n=$row['Name'];
        echo"<ul class='nav navbar-nav navbar-right'>
          <li class='dropdown'><a class='dropdown-toggle' data-toggle='dropdown' href='#'>Hello,".$n."<span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../html/password.html''>Change Password</a></li>
            <li><a href='userorder.php'>Your orders</a></li>
           <li><a href='logout.php'>Sign out</a></li>
          </ul>
          </li>
         <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
         </ul>";
      }
    ?>
    


  </div>
</nav>

	<div class="container-fluid" style="margin: 0;" id="5">
		<div class="jumbotron">
			<div class="subb" id="myDiv">
				<h1 style="text-align: left; color: #cc0000; font-family: Satisfy; padding-left: 50px;">The team</h1>	
				<h1 style="text-align: left; color: #cc0000; font-family: Satisfy; padding-left: 50px;">behind V-Store</h1>
			</div>
		</div>
		
	</div>

	<div class="container">
	  <div class="row" id="1">
		   <div class="col-md-4">
		      <div class="thumbnail">
		        <a href="../images/sandeep1.jpg" target="_blank">
		          <img src="../images/sandeep1.jpg" alt="Lights" style="height: 350px" class="img-circle">
		          
		        </a>
		        <div class="caption">
		        	<a href="#" target="_blank" style="text-decoration: none;"><h1 style="text-align: center; font-family: algerian; color: #cc0000">Sai Sandeep</h1></a>
		        	<h2 style="text-align: center; font-family: Satisfy">Founder</h2>
		        	<!--<a href="#"><h3 style="text-align: center;">Show Bio</h3></a>-->
		          </div>
		            
		      </div>
	    	</div>
	    	<div class="col-md-4">
		      <div class="thumbnail">
		        <a href="../images/sayooj.jpg" target="_blank">
		          <img src="../images/sayooj.jpg" alt="Lights" style="height: 350px" class="img-circle">
		        </a>
		        <div class="caption">
		        	<a href="#" target="_blank" style="text-decoration: none;"> <h1 style="text-align: center; font-family: algerian; color: #cc0000">Sayooj Surendran</h1></a>
		        	<h2 style="text-align: center; font-family: Satisfy; padding-top: -50px;">Founder</h2>
		        
		          </div>
		       
		      </div>
	    	</div>
	    	
	     <div class="col-md-4">
		      <div class="thumbnail">
		        <a href="../images/puru.jpg" target="_blank">
		          <img src="../images/puru.jpg" alt="Lights" style="height: 350px" class="img-circle">
		        
		        </a>
		         <div class="caption">
		         	<a href="#" target="_blank" style="text-decoration: none;"><h1 style="text-align: center; font-family: algerian; color: #cc0000">Purujit Chaugule</h1></a>
		        <h2 style="text-align: center; font-family: Satisfy">Founder</h2>
		            
		          </div>
		        
		      </div>
	    	</div>
	  </div>

	  <div class="row" id="2">
	  		<div class="col-md-2">
	  			
	  		</div>
	  		<div class="col-md-4">
		      <div class="thumbnail">
		        <a href="../images/prabhu1.jpg" target="_blank">
		          <img src="../images/prabhu1.jpg" alt="Lights" style="height: 350px" class="img-circle">
		          
		        </a>
		           <div class="caption">
		           	<a href="#" target="_blank" style="text-decoration: none;"><h1 style="text-align: center; font-family: algerian; color: #cc0000">Prabhu Vikas</h1></a>
		        	<h2 style="text-align: center; font-family: Satisfy">Founder</h2>
		          </div>

		      </div>
	    	</div>
		    
	    <div class="col-md-4">
		      <div class="thumbnail">
		        <a href="../images/sashi1.jpg" target="_blank">
		          <img src="../images/sashi1.jpg" alt="Lights" style="height: 350px" class="img-circle">
		         
		        </a>
		         <div class="caption">
		         	<a href="#" target="_blank" style="text-decoration: none;"><h1 style="text-align: center; font-family: algerian; color: #cc0000">Sashidhar Nenavath</h1></a>
		        <h2 style="text-align: center; font-family: Satisfy">Founder</h2>
		            
		          </div>
		        
		      </div>
	    	</div>
	</div>

	<!--Styles-->
	<style type="text/css">
		.pagetopblue{
			padding-top: 60px;
		}
		.jumbotron{
 		   width: 100%;
 		   padding-top: 40px;
 		   padding-right: 0px;
 		   background-repeat: no-repeat; 
 		   background-color: transparent;
 		   background-size: 100% 100%;
 		   
		}
		body{
			background-image: url(img/food3.jpg);
			background-color: 	rgb(230, 230, 255);
			background-size: cover;
		}
		.subb{
			opacity: 100;
		}
		.thumbnail{
			text-align: center;
			background-color: rgb(230, 230, 255);
			
			float: none;
		}
		
		a{
			text-decoration: none;
		}
	</style>
	
</body>
</html>