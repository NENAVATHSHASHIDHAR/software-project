
<?php
session_start();
include('database.php');
$m = $_SESSION['mail'];
$p = $_SESSION['pass'];
$new = $_POST['password'];
$sql="UPDATE userdetails SET Password='$new' WHERE Email='$m' AND Password='$p'";
$result = $conn->query($sql);
$_SESSION['pass']=$new;
echo "<script type='text/javascript'>alert('The password has been changed successfully');</script>";
header( "refresh:0; url=home.php" );


?>




