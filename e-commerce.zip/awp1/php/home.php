<?php 
session_start();
include('config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>V-Store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      max-height:500px;
  }
  .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    .jumbotron {
      margin-bottom: 0;
    }
  #first{
    margin-top: 30px;
  }
  </style>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center">
    <h1>V-Store</h1>      
    <p>The best place to shop</p>
  </div>
</div>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li><a href="../php/about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Electronics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/mobile.php">Mobiles and Accessories</a></li>
          <li><a href="../php/computer.php">Computers and Accessories</a></li>
          <li><a href="../php/camera.php">Cameras and Peripherals</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clothing and Footwear<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/men.php">Men</a></li>
          <li><a href="../php/women.php">Women</a></li>
          <li><a href="../php/kids.php">Kids</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Books and More<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../php/book1.php">Books</a></li>
          <li><a href="../php/gaming.php">Gaming</a></li>
        </ul>
      </li>
    </ul>

    <form class="navbar-form navbar-left" action="search.php">
      <div class="input-group">
        <input type="text" class="form-control" name="query" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>

    <?php
    if(empty($_SESSION['mail']))
    {
        echo"<ul class='nav navbar-nav navbar-right'>
          <li><a href='../html/signup.html'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>
          <li><a href='../html/login.html'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>
          <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
        </ul>";
      }
      else
      {
        $a = $_SESSION['mail'];
        $b = $_SESSION['pass'];
        $sql="SELECT * FROM userdetails WHERE Email='$a' AND Password='$b'";
        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();
        $n=$row['Name'];
        $_SESSION['name']=$n;
        echo"<ul class='nav navbar-nav navbar-right'>
          <li class='dropdown'><a class='dropdown-toggle' data-toggle='dropdown' href='#'>Hello,".$n."<span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../html/password.html'>Change Password</a></li>
            <li><a href='userorder.php'>Your orders</a></li>
           <li><a href='logout.php'>Sign out</a></li>
          </ul>
          </li>
         <li><a href='../php/view_cart.php'><span class='glyphicon glyphicon-shopping-cart'></span> Cart</a></li>
         </ul>";
      }
    ?>
    


  </div>
</nav>


<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <a href="../php/computer.php"><img src="../images/laptop.jpg" alt="Image"></a>      
      </div>

      <div class="item">
        <a href="../php/mobile.php"><img src="../images/phone.jpg" alt="Image"></a> 
      </div>

      <div class="item">
        <a href="../php/book1.php"><img src="../images/book.jpg" alt="Image"></a> 
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>


<div class="container">    
  <div class="row" id="first">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Mobiles</div>
        <div class="panel-body"><a href="../php/mobile.php"><img src="../images/mob.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Computers</div>
        <div class="panel-body"><a href="../php/computer.php"><img src="../images/Laptop2.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">Cameras</div>
        <div class="panel-body"><a href="../php/camera.php"><img src="../images/cam.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
  </div>
</div><br>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Books</div>
        <div class="panel-body"><a href="../php/book1.php"><img src="../images/book1.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Gaming</div>
        <div class="panel-body"><a href="../php/gaming.php"><img src="../images/fifas.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">Men</div>
        <div class="panel-body"><a href="../php/men.php"><img src="../images/men.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Women</div>
        <div class="panel-body"><a href="../php/women.php"><img src="../images/women.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Kids</div>
        <div class="panel-body"><a href="../php/kids.php"><img src="../images/kid.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
  </div>
</div><br><br>


<br><br>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav navbar-left">
      <li><a href="../html/sellerlogin.html"><span class="glyphicon glyphicon-log-in"></span>Seller Login</a></li>
      <li><a href="../html/adminlogin.html"><span class="glyphicon glyphicon-log-in"></span>Admin Login</a></li>
    </ul>
  </div>
</nav>

</body>
</html>
