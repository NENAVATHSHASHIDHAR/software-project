<?php  

$conn = mysqli_connect("localhost","root","","Database");

if(!$conn) {
	die("Connection failed: ".mysqli_connect_error());
}

?>