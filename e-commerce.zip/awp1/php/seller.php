<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>V-Store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    .jumbotron {
      margin-bottom: 0;
    }
  #first{
    margin-top: 30px;
  }
  </style>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center">
    <h1>V-Store<small>seller</small></h1>      
    <p>Where you can sell anything</p>
  </div>
</div>



    <?php
    include 'database.php';
    $a = $_SESSION['mail'];
    $b = $_SESSION['pass'];
    $conn = mysqli_connect('localhost', 'root','', 'database');
    $sql = "select * from sellerdetails";
    $rs = $conn->query($sql);
    while($row = $rs->fetch_assoc()){
        if($row['email'] == $a && $row['password'] == $b){
            $n=$row['name'];
        }
      }   
    ?>

    
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  	  <div class="navbar-header">
      <a class="navbar-brand" href="#">
              <span style = "color:white"><span style = "color:red">V</span>-<span style = "color:red">S</span>tore</span>
          </a>
      </div>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="about.php">About Us</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hello,<?php echo $n;?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../html/sellerpass.html">Change Password</a></li>
          <li><a href="viewproducts.php">Your items</a></li>
          <li><a href="logout.php">Sign out</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>


<div class="container">    
  <div class="row" id="first">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Add a new item</div>
        <div class="panel-body"><a href="../html/additem.html"><img src="../images/selleradd.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">View your current items</div>
        <div class="panel-body"><a href="../php/viewproducts.php"><img src="../images/products.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">See your orders</div>
        <div class="panel-body"><a href="sellerorder.php"><img src="../images/sale.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
  </div>
</div><br>
</body>
</html>
