<?php

include 'database.php';

$a = $_POST['name'];
$b = $_POST['number'];
$c = $_POST['email'];
$d = $_POST['password'];


$sql = "INSERT INTO  sellerDetails VALUES('$a','$b','$c','$d')";
$result = $conn->query($sql);
header("Location: ../html/Sellerlogin.html");
?>
