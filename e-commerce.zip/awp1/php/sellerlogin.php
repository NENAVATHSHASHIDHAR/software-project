<?php
session_start();
?>
<?php

include 'database.php';

$a = $_POST['email'];
$_SESSION['mail'] = $a;
$b = $_POST['password'];
$_SESSION['pass'] = $b;

$sql = "SELECT * FROM sellerDetails WHERE email='$a' AND password='$b' ";
$result = $conn->query($sql);
if (!$row = $result->fetch_assoc()) {
	echo "<script type='text/javascript'>alert('The username or password is incorrect');</script>";
	header( "refresh:0; url=../html/sellerlogin.html" );
}
else{
	header("Location: ../php/seller.php");
}

?>
