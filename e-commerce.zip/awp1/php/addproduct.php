<?php
session_start();
include 'config.php';

$a = $_POST['name'];
$b = $_POST['price'];
$c = $_POST['quantity'];
$d = $_POST['type'];
$i = $_POST['image'];
$z = $_POST['id'];

    $conn = mysqli_connect('localhost', 'root','', 'database');
    $sql = "select * from sellerdetails";
    $rs = $conn->query($sql);
    $x = $_SESSION['mail'];
    $y = $_SESSION['pass'];
    while($row = $rs->fetch_assoc()){
        if($row['email'] == $x && $row['password'] == $y){
           $g = $row['name'];
        }
      }   

$sql = "INSERT INTO products(name,price,quantity,type,image,seller,id) VALUES('$a','$b','$c','$d','../images/$i','$g','$z')";
$result = $conn->query($sql);
header("Location: ../php/seller.php");
?>
