<?php
session_start();
?>
<?php
include 'database.php';

$a = $_POST['email'];
$_SESSION['mail'] = $a;
$b = $_POST['password'];
$_SESSION['pass'] = $b;


$sql = "SELECT * FROM userDetails WHERE Email='$a' AND Password='$b' ";
$result = $conn->query($sql);
if (!$row = $result->fetch_assoc()) {
	echo "<script type='text/javascript'>alert('The username or password is incorrect');</script>";
	header( "refresh:0; url=../html/login.html" );
}
else{
	header("Location:home.php");
}

?>
