<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>V-Store</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    .jumbotron {
      margin-bottom: 0;
    }
  #first{
    margin-top: 30px;
  }
  </style>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center">
    <h1>V-Store<small>admin</small></h1>      
  </div>
</div>



    <?php
    include 'database.php';
    $a = $_SESSION['mail'];
    $b = $_SESSION['pass'];
    $conn = mysqli_connect('localhost', 'root','', 'database');
    $sql = "select * from admin";
    $rs = $conn->query($sql);
    while($row = $rs->fetch_assoc()){
        if($row['Email'] == $a && $row['Password'] == $b){
            $n=$row['Name'];
        }
      }   
    ?>

    
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
  	  <div class="navbar-header">
      <a class="navbar-brand" href="#">
              <span style = "color:white"><span style = "color:red">V</span>-<span style = "color:red">S</span>tore</span>
          </a>
      </div>
      <ul class="nav navbar-nav navbar-right">
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hello,<?php echo $n;?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="../html/adminpass.html">Change Password</a></li>
          <li><a href="logout.php">Sign out</a></li>
        </ul>
      </li>
      <li><a href="about.php">About Us</a></li>
    </ul>
  </div>
</nav>


<div class="container">    
  <div class="row" id="first">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">View list of users</div>
        <div class="panel-body"><a href="user.php"><img src="../images/user.png" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">View list of sellers</div>
        <div class="panel-body"><a href="sellerlist.php"><img src="../images/seller.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">View entire list of products</div>
        <div class="panel-body"><a href="list.php"><img src="../images/products.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">View list of products sold</div>
        <div class="panel-body"><a href="soldlist.php"><img src="../images/iph.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">View list of products brought by each user</div>
        <div class="panel-body"><a href="useritems.php"><img src="../images/userproduct.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">View list of products sold by each seller</div>
        <div class="panel-body"><a href="selleritems.php"><img src="../images/sellerproduct.jpg" class="img-responsive" style="width:100%;height:250px" alt="Image"></a></div>
        
      </div>
    </div>

  </div>
</div><br>
</body>
</html>
