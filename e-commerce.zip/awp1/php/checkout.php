<?php

session_start();
include_once("config.php");
$a = $_SESSION['mail'];
$b = $_SESSION['pass'];
$sql = "select * from userdetails";
$rs = $mysqli->query($sql);

while($row = $rs->fetch_assoc()){    
    if($row['Email'] == $a && $row['Password'] == $b){
        $n=$row['Name'];
    }
}   

if(isset($_SESSION["cart_products"])) //check session var
    { 
		foreach ($_SESSION["cart_products"] as $cart_itm)
        {
			//set variables to use in content below
			$name = $cart_itm["product_name"];
			$qty = $cart_itm["product_qty"];
			$price = $cart_itm["product_price"];
			$seller = $cart_itm["product_seller"];
			$code = $cart_itm["id"];
			$sql ="SELECT * FROM products WHERE id='$code' LIMIT 1";
			$r = $mysqli->query($sql);
			$row = $r->fetch_assoc();
			$newqty = $row['quantity'] - $qty;
			if($newqty>0)
			{
				$sql = "UPDATE products SET quantity=$newqty WHERE id='$code'";
				$r = $mysqli->query($sql);
				$sql="INSERT INTO solditems VALUES('$name','$price','$qty','$n','$seller')";
				$result=$mysqli->query($sql);
				echo "<script type='text/javascript'>alert('Your order has been placed successfully');</script>";
				header( "refresh:0; url=home.php" );
				unset($_SESSION["cart_products"]);
			}
			elseif($newqty<0)
			{
				echo "<script type='text/javascript'>alert('Sorry, The quantity you have requested for is not available');</script>";
				header( "refresh:0; url=../php/view_cart.php" );
			}
			else
			{
				$sql = "DELETE FROM products WHERE id='$code'";
				$r = $mysqli->query($sql);
				$sql="INSERT INTO solditems VALUES('$name','$price','$qty','$n','$seller')";
				$result=$mysqli->query($sql);
				echo "<script type='text/javascript'>alert('Your order has been placed successfully');</script>";
				header( "refresh:0; url=home.php" );
				unset($_SESSION["cart_products"]);
			}
		}
	}
?>