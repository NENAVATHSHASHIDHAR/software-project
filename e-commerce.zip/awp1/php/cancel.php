<?php
session_start();
?>
<?php
include 'database.php';

$a = $_POST['product'];
$n = $_POST['user'];


$sql="DELETE FROM solditems WHERE name='$a' AND buyer='$n'";
 $s=mysqli_query($conn,$sql);
 echo "<script type='text/javascript'>alert('Your order hs been cancelled succesfully');</script>";
  header( "refresh:0; url=userorder.php" );

?>
